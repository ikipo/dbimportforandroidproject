package importdata.nhung.vn;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.database.Cursor;
import java.lang.Exception;

public class importdataActivity extends Activity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        try {
        DataAdapter data = new DataAdapter (this);
        data.createDatabase();
        data.open();     
        Cursor c = data.getData ();
        if (c!=null) {
        c.moveToFirst();
        do {
        String str = c.getInt (0)+" -- ";
        str += c.getString (2)+"";
        Toast.makeText (this,str,Toast.LENGTH_SHORT).show ();
        }while(c.moveToNext());
        }
        data.close ();
        }catch (Exception e){
        Toast.makeText (this,e.getMessage().toString(),Toast.LENGTH_SHORT).show ();        
        }
    }
}
